---
layout: post
date: 2023-08-01 15:59:00-0400
inline: true
---

Our paper **A Manifold View of Connectivity in the Private Backbone Networks of Hyperscalers** has been published in Communications of the ACM (CACM) as a Research Highlight!
