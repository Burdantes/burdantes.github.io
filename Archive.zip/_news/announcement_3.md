---
layout: post
date: 2023-05-01 15:59:00-0400
inline: true
---

Our paper on **Who are the IPv4 squatters?** was accepted at SIGCOMM Computer Communication Review - <span style="color: red;">Awarded best of CCR</span>.
