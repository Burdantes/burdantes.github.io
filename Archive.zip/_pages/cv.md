---
layout: cv
permalink: /cv/
title: CV
description: My CV/resume

news: false
social: false
---

### full CV

My full CV can be found <a class="page-link" href="{{ '/cv/Curriculum_Vitae.pdf' | prepend: site.baseurl | prepend: site.url }}">here</a> .

------
