---
layout: page
title: research
permalink: /research/
description: My teaching so far

---

### Teaching Service:

I had the pleasure of serving as a Course Assistant on two occasions for <a href="http://www.cs.columbia.edu/~misra/6180.html" >CSEEW6180 Modeling Performance Evaluation</a> (old website) with Professor Vishal Misra. My responsibilities encompassed drafting and evaluating homework, overseeing the final examinations, and conducting office hours.
